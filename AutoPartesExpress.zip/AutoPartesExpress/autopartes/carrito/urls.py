from django.urls import path
from .views import (
    agregar_al_carrito,
    ver_carrito,
    actualizar_item_carrito,
    eliminar_item_carrito
    )
from venta.views import finalizar_pedido

urlpatterns = [
    path('agregar/<int:producto_id>/', agregar_al_carrito, name='agregar_al_carrito'),
    path('', ver_carrito, name='ver_carrito'),
    path('actualizar/<int:item_id>/', actualizar_item_carrito, name='actualizar_item_carrito'),
    path('eliminar/<int:item_id>/', eliminar_item_carrito, name='eliminar_item_carrito'),
    path('finalizar/', finalizar_pedido, name='finalizar_pedido'),

]