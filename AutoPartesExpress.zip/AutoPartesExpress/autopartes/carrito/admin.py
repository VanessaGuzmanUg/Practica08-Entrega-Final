from django.contrib import admin
from .models import Carrito
# Register your models here.
admin.site.register(Carrito)