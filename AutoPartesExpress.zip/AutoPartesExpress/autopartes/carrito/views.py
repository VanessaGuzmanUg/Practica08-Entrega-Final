# carrito/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Carrito, CarritoItem
from producto.models import Producto
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

@login_required
def agregar_al_carrito(request, producto_id):
    producto = get_object_or_404(Producto, producto_id=producto_id)
    carrito, creado = Carrito.objects.get_or_create(usuario_id=request.user.id, completado=False)

    item, creado = CarritoItem.objects.get_or_create(carrito=carrito, producto=producto)
    if not creado:
        item.cantidad += 1
    item.save()
    return redirect('ver_carrito')


@login_required
def ver_carrito(request):
    carrito = Carrito.objects.filter(usuario_id=request.user.id, completado=False).first()
    if carrito:
        usuario = User.objects.get(id=carrito.usuario_id)
    else:
        usuario = request.user

    context = {
        'carrito': carrito,
        'usuario_actual': usuario  # Pasamos el objeto User completo
    }
    return render(request, 'carrito/carrito.html', context)


@login_required
def actualizar_item_carrito(request, item_id):
    item = get_object_or_404(CarritoItem, id=item_id)
    if request.method == 'POST':
        cantidad = int(request.POST.get('cantidad', 1))
        item.cantidad = cantidad
        item.save()
    return redirect('ver_carrito')


@login_required
def eliminar_item_carrito(request, item_id):
    item = get_object_or_404(CarritoItem, id=item_id)
    item.delete()
    return redirect('ver_carrito')
