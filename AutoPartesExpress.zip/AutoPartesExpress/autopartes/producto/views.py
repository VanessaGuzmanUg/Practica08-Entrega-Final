
from django.core.paginator import Paginator
from django.shortcuts import render, redirect
from .models import Producto
from categoria.models import Categoria
# Create your views here.
def productos_vista(request):
    # Obtener parámetros de filtrado
    categoria_filtro = request.GET.get('categoria', '')
    busqueda = request.GET.get('busqueda', '')

    # Obtener todos los productos (o filtrados)
    productos_lista = Producto.objects.all()

    # Aplicar filtros
    if categoria_filtro:
        productos_lista = productos_lista.filter(categoria=categoria_filtro)

    if busqueda:
        productos_lista = productos_lista.filter(
            models.Q(nombre__icontains=busqueda) |
            models.Q(descripcion__icontains=busqueda)
        )

    # Paginación (10 productos por página)
    paginator = Paginator(productos_lista, 10)
    page_number = request.GET.get('page')
    productos = paginator.get_page(page_number)

    # Obtener todas las categorías disponibles para el filtro
    categorias_disponibles = Categoria.objects.all()

    context = {
        'productos': productos,
        'categorias_disponibles': categorias_disponibles,
    }
    return render(request, 'producto/productos.html', context)

def agregar_producto(request):
    categorias = Categoria.objects.all()
    if request.method == 'POST':
        producto = Producto()
        producto.nombre = request.POST['nombre']
        producto.descripcion = request.POST['descripcion']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.categoria = request.POST['categoria']

        # Manejo de la imagen
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']

        producto.save()
        return redirect(productos_vista)
    context = {
        'categorias': categorias
    }
    return render(request, 'producto/form.html', context)

def editar_producto(request, producto_id):
    producto = Producto.objects.get(pk=producto_id)
    categorias = Categoria.objects.all()
    if request.method == 'POST':
        producto.nombre = request.POST['nombre']
        producto.descripcion = request.POST['descripcion']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.categoria = request.POST['categoria']

        # Manejo de la imagen
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']

        producto.save()
        return redirect(productos_vista)
    context = {
        'producto': producto,
        'categorias': categorias
    }
    return render(request, 'producto/form.html', context)

def eliminar_producto(request, producto_id):
    producto = Producto.objects.get(pk=producto_id)
    producto.delete()
    return redirect(productos_vista)

