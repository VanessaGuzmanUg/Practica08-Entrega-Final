from django.urls import path
from .views import (
productos_vista,
agregar_producto,
editar_producto,
eliminar_producto,
)
urlpatterns = [
    path("", productos_vista, name="productos_vista"),
    path("agregar/", agregar_producto, name="agregar_producto"),
    path("editar/<int:producto_id>", editar_producto, name="editar_producto"),
    path("eliminar/<int:producto_id>", eliminar_producto, name="eliminar_producto"),

]