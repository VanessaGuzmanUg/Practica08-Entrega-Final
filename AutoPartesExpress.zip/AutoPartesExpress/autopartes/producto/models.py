import os
from django.db import models
from PIL import Image, UnidentifiedImageError
from io import BytesIO
from django.core.files.base import ContentFile

# Create your models here.
class Producto(models.Model):
    producto_id = models.IntegerField(primary_key=True)
    nombre = models.CharField(max_length=150, null=False, blank=False)
    descripcion = models.TextField()
    precio = models.DecimalField(max_digits=10, decimal_places=2, null=False, blank=False)
    stock = models.IntegerField(default=0, null=False, blank=False)
    imagen = models.ImageField(upload_to='images_productos/', blank=True, null=True)
    thumbnail = models.ImageField(upload_to='thumbs', blank=True, null=True, editable=False)
    categoria = models.CharField(max_length=150, null=False, blank=False)

    def __str__(self):
        return self.nombre

    def save(self, *args, **kwargs):
        creating = self._state.adding
        imagen_original = self.imagen

        super(Producto, self).save(*args, **kwargs)  # Guardar primero para tener ID

        # Generar thumbnail si la imagen existe y el objeto fue creado o la imagen ha cambiado
        if self.imagen and (creating or self.imagen != imagen_original):
            try:
                self.make_thumbnail()
            except UnidentifiedImageError:
                print("Error: imagen no válida.")
            except Exception as e:
                print(f"Error generando thumbnail: {e}")

    def make_thumbnail(self):
        self.imagen.open()  # Abrir imagen
        imagen = Image.open(self.imagen)
        imagen.convert('RGB')  # Asegura compatibilidad

        thumbnail_size = (75, 75)
        imagen.thumbnail(thumbnail_size)

        thumb_name, thumb_extension = os.path.splitext(self.imagen.name)
        thumb_extension = thumb_extension.lower()

        FTYPE = 'JPEG'
        if thumb_extension == '.png':
            FTYPE = 'PNG'
        elif thumb_extension == '.gif':
            FTYPE = 'GIF'

        temp_thumb = BytesIO()
        imagen.save(temp_thumb, FTYPE)
        temp_thumb.seek(0)

        thumb_filename = f"{thumb_name}_thumb{thumb_extension}"
        self.thumbnail.save(thumb_filename, ContentFile(temp_thumb.read()), save=False)
        temp_thumb.close()

        # Guardar solo el campo de thumbnail para evitar bucles infinitos
        Producto.objects.filter(pk=self.pk).update(thumbnail=self.thumbnail)