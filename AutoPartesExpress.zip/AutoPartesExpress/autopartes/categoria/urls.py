from django.urls import path
from .views import (
    categoria_vista,
    agregar_categoria,
    editar_categoria,
    eliminar_categoria,
    )
urlpatterns = [
    path('', categoria_vista, name='categoria_vista'),
    path('crear/', agregar_categoria, name='agregar_categoria'),
    path('editar/<int:categoria_id>', editar_categoria, name='editar_categoria'),
    path('eliminar/<int:categoria_id>', eliminar_categoria, name='eliminar_categoria'),
]
