

from django.shortcuts import render, redirect
from .models import Categoria
# Create your views here.
def categoria_vista(request):
    categorias = Categoria.objects.all()
    context = {
        'categorias': categorias,
    }
    return render(request, 'categoria/categorias.html', context)

def agregar_categoria(request):
    if request.method == 'POST':
        categoria = Categoria()
        categoria.nombre = request.POST['nombre']
        categoria.descripcion = request.POST['descripcion']
        categoria.save()
        return redirect('categoria_vista')
    return render(request, 'categoria/form.html')

def editar_categoria(request, categoria_id):
    categoria = Categoria.objects.get(pk=categoria_id)
    if request.method == 'POST':
        categoria.nombre = request.POST['nombre']
        categoria.descripcion = request.POST['descripcion']
        categoria.save()
        return redirect('categoria_vista')
    context = {
        'categoria': categoria,
    }
    return render(request, 'categoria/form.html', context)

def eliminar_categoria(request, categoria_id):
    categoria = Categoria.objects.get(pk=categoria_id)
    categoria.delete()
    return redirect('categoria_vista')

