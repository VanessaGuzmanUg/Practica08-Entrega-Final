from django.urls import path
from .views import (
    vehiculos_vista,
    agregar_vehiculo,
    editar_vehiculo,
    eliminar_vehiculo,
)
urlpatterns = [
    path('', vehiculos_vista, name='vehiculos_vista'),
    path('agregar_vehiculo/', agregar_vehiculo, name='agregar_vehiculo'),
    path('editar_vehiculo/<int:vehiculo_id>/', editar_vehiculo, name='editar_vehiculo'),
    path('eliminar_vehiculo/<int:vehiculo_id>/', eliminar_vehiculo, name='eliminar_vehiculo'),

]