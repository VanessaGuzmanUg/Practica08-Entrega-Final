from django.contrib import admin
from .models import Vehiculo
# Register your models here.
admin.site.register(Vehiculo)