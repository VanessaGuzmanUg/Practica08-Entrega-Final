

from django.shortcuts import render, redirect

import vehiculos
from producto.models import Producto
from .models import Vehiculo
# Create your views here.
def vehiculos_vista(request):
    vehiculos = Vehiculo.objects.all().order_by('marca')
    context = {
        'vehiculos': vehiculos,
    }
    return render(request, 'vehiculo/vehiculos.html', context)

def agregar_vehiculo(request):
    productos = Producto.objects.all()
    if request.method == 'POST':
        vehiculo = Vehiculo()
        vehiculo.marca = request.POST['marca']
        vehiculo.modelo = request.POST['modelo']
        vehiculo.anio_inicio = request.POST['anio_inicio']
        vehiculo.anio_final = request.POST['anio_final']
        vehiculo.producto_id = request.POST['producto_id']
        vehiculo.save()
        return redirect('vehiculos_vista')
    context = {
        'vehiculos': vehiculos,
        'productos': productos,
    }
    return render(request, 'vehiculo/form.html', context)

def editar_vehiculo(request, vehiculo_id):
    vehiculo = Vehiculo.objects.get(pk=vehiculo_id)
    productos = Producto.objects.all()
    if request.method == 'POST':
        vehiculo.marca = request.POST['marca']
        vehiculo.modelo = request.POST['modelo']
        vehiculo.anio_inicio = request.POST['anio_inicio']
        vehiculo.anio_final = request.POST['anio_final']
        vehiculo.producto_id = request.POST['producto_id']
        vehiculo.save()
        return redirect('vehiculos_vista')
    context = {
        'vehiculo': vehiculo,
        'productos': productos,
    }
    return render(request, 'vehiculo/form.html', context)

def eliminar_vehiculo(request, vehiculo_id):
    vehiculo = Vehiculo.objects.get(pk=vehiculo_id)
    vehiculo.delete()
    return redirect('vehiculos_vista')