from django.db import models

# Create your models here.
class Vehiculo(models.Model):
    vehiculo_id = models.IntegerField(primary_key=True)
    marca = models.CharField(max_length=100, null=False, blank=False)
    modelo = models.CharField(max_length=100, null=False, blank=False)
    anio_inicio = models.IntegerField(null=False, blank=False)
    anio_final = models.IntegerField(null=False, blank=False)
    producto_id = models.CharField(null=False, blank=False)

    def __str__(self):
        return f"Vehiculo {str(self.vehiculo_id)} con modelo {self.modelo}"