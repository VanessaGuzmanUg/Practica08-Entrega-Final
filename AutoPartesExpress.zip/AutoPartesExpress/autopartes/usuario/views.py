

from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import authenticate, login
from django.core.paginator import Paginator
from django.shortcuts import render, redirect
from django.db.models import Q
from producto.models import Producto
from categoria.models import Categoria
from django.contrib.auth.models import User, Group
from django.contrib import messages

def index(request):
    if request.user.is_authenticated:
        # Obtener parámetros de filtrado
        categoria_filtro = request.GET.get('categoria', '')
        busqueda = request.GET.get('busqueda', '')

        # Obtener todos los productos
        productos_lista = Producto.objects.all().order_by('nombre')

        # Aplicar filtros
        if categoria_filtro:
            productos_lista = productos_lista.filter(categoria__iexact=categoria_filtro)

        if busqueda:
            productos_lista = productos_lista.filter(
                Q(nombre__icontains=busqueda) |
                Q(descripcion__icontains=busqueda))

        # Obtener categorías únicas para el filtro
        categorias_unicas = Producto.objects.values_list('categoria', flat=True).distinct()

        # Paginación (12 productos por página)
        paginator = Paginator(productos_lista, 12)
        page_number = request.GET.get('page')
        productos = paginator.get_page(page_number)

        context = {
            'productos': productos,
            'categorias_unicas': categorias_unicas,
        }
        return render(request, 'index.html', context)
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)

                # Redirección según grupo del usuario
                if user.groups.filter(name='Cliente').exists():
                    return redirect('index')
                elif user.is_staff:
                    return redirect('admin:index')  # Redirige al admin si es staff
                else:
                    return redirect('index')
            else:
                messages.error(request, 'Usuario o contraseña incorrectos.')
                return redirect('index')

        return render(request, 'login.html')


def registrar(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        # Validaciones básicas
        if password1 != password2:
            messages.error(request, 'Las contraseñas no coinciden.')
            return redirect('registrar')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'El nombre de usuario ya existe.')
            return redirect('registrar')

        if User.objects.filter(email=email).exists():
            messages.error(request, 'El correo electrónico ya está registrado.')
            return redirect('registrar')

        try:
            # Crear el usuario
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password1
            )

            # Asignar al grupo "Cliente"
            cliente_group = Group.objects.get(name='Cliente')
            user.groups.add(cliente_group)

            messages.success(request, 'Registro exitoso. Ahora puedes iniciar sesión.')
            return redirect('index')

        except Group.DoesNotExist:
            messages.error(request, 'El grupo Cliente no existe. Contacta al administrador.')
            return redirect('registrar')
        except Exception as e:
            messages.error(request, f'Ocurrió un error: {str(e)}')
            return redirect('registrar')

    return render(request, 'registrar.html')

def is_admin(user):
    return user.groups.filter(name='Administrador').exists()

def login_admin(request):
    if request.user.is_authenticated and is_admin(request.user):
        return redirect('panel')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None and is_admin(user):
            login(request, user)
            return redirect('panel')
        else:
            messages.error(request, 'Credenciales inválidas o no tiene permisos de administrador')
            return redirect('login_admin')

    return render(request, 'login_admin.html')

@login_required(login_url='login_admin')
@user_passes_test(is_admin, login_url='acceso_denegado')
def panel(request):
    categorias = Categoria.objects.count()
    productos = Producto.objects.count()
    context = {
        'categorias': categorias,
        'productos': productos,
    }
    return render(request, 'panel.html', context)

def acceso_denegado(request):
    messages.warning(request, 'Acceso restringido: Solo para administradores')
    return redirect('index')