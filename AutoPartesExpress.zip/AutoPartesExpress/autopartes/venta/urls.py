from django.urls import path
from .views import ventas_vista

urlpatterns = [
    path('', ventas_vista, name='ventas_vista'),
]