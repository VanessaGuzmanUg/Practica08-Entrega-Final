from django.shortcuts import redirect, get_object_or_404, render
from carrito.models import Carrito, CarritoItem
from .models import Venta
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User

@login_required
def finalizar_pedido(request):
    # Obtener el carrito actual del usuario
    carrito = Carrito.objects.filter(usuario_id=request.user.id, completado=False).first()

    if not carrito:
        messages.warning(request, "No tienes productos en el carrito.")
        return redirect('listar_productos')  # Ajusta según tu vista principal

    total = carrito.total_carrito()

    # Crear venta
    venta = Venta.objects.create(
        total=total,
        usuario_id=request.user.id
    )

    # Marcar carrito como completado y eliminar sus ítems
    carrito.delete()  # Esto también elimina los CarritoItem por on_delete=models.CASCADE

    messages.success(request, f"¡Pedido realizado! Venta #{venta.venta_id}")
    return redirect('index')


def ventas_vista(request):
    # Obtener todas las ventas
    ventas = Venta.objects.all()

    # Filtro por búsqueda
    busqueda = request.GET.get('busqueda', '')
    if busqueda:
        ventas = ventas.filter(venta_id__icontains=busqueda)

    # Obtener todos los IDs de usuario únicos de las ventas
    usuario_ids = ventas.values_list('usuario_id', flat=True).distinct()

    # Obtener los usuarios correspondientes en una sola consulta
    usuarios = User.objects.filter(id__in=usuario_ids)

    # Crear un diccionario para acceso rápido {id: usuario}
    usuarios_dict = {user.id: user for user in usuarios}

    # Preparar los datos para el template
    ventas_data = []
    for venta in ventas:
        usuario = usuarios_dict.get(venta.usuario_id)
        ventas_data.append({
            'venta': venta,
            'usuario': usuario  # Esto será None si no se encuentra el usuario
        })

    context = {
        'ventas_data': ventas_data,  # Usamos esta nueva estructura
        'busqueda': busqueda,
    }
    return render(request, 'ventas.html', context)
