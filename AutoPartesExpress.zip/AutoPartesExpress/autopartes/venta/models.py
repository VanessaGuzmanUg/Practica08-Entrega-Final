from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Venta(models.Model):
    venta_id = models.AutoField(primary_key=True)
    total = models.DecimalField(max_digits=10, decimal_places=2, null=False, blank=False)
    usuario_id = models.IntegerField(null=False, blank=False)

    def __str__(self):
        return f"Venta #{self.venta_id} - {self.usuario.username}"